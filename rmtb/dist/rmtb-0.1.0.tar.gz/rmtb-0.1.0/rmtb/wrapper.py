class converter:
	e2f = {
		"user joined": "user_joined",
		"user left": "user_left",
		"message": "message",
		"update users": "update_users",
		"user change nick": "user_change_nick",
		"get_voice_users": "get_voice_users",
		"getvoice": "get_voice",
		"typing": "typing",
		"reaction_add": "reaction_add",
		"reaction_remove": "reaction_remove",
		"reaction_update": "reaction_update",
		"lts_msgid": "lts_msgid"
	}
	def arg(data) -> tuple:
		finished = ()
		for k, v in data:
			finished += (v,)
		return finished
	