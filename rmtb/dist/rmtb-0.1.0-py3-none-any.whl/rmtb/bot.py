from .wrapper import *
import requests as r
import websocket, json, rel, time

class Bot:
	URL = "://rmtrollbox.eu-gb.mybluemix.net/"
	events = {}
	sid = None
	HEARTBEAT = 0
	def __init__(self, name, color, bot=True):
		self.name = name
		self.color = color
		self.bot = bot
	def _ping(self, ws):
		while True:
			ws.send("2")
			time.sleep(HEARTBEAT/1000)
	def event(self, func):
		self.events[func.__name__] = func
	def _message(self, ws, msg):
		if msg == "3probe":
			ws.send(5)
		else:
			print(msg)
	def _error(self, ws, err):
		print(err)
	def _close(self, ws, status, msg):
		print(status, msg)
	def _on_connect(self, ws):
		ws.send("2probe")
		self.pingt = threading.Thread(target=self._ping,args=(ws,),daemon=True)
		self.pingt.start()
	def run(self):
		stuff = json.loads(r.get("https"+self.URL+"socket.io/?EIO=3&transport=polling").text[4:-4])
		self.sid = stuf["sid"]
		self.HEARTBEAT = stuff["pingInterval"]
		ws = websocket.WebSocketApp("wss"+self.URL+"socket.io/?EIO=3&transport=websocket&sid="+self.sid,
                              on_open=self._open,
                              on_message=self._message,
                              on_error=self._error,
                              on_close=self._close)
		ws.run_forever(dispatcher=rel)
		rel.signal(2, rel.abort)
		rel.dispatch()